#ifndef PROCEDURALWORLD_APPLICATION_H
#define PROCEDURALWORLD_APPLICATION_H

#include "Input.h"

void ApplicationUpdateAndRender(input_form* InputForm);
void ApplicationShutdown();

#endif //PROCEDURALWORLD_APPLICATION_H
