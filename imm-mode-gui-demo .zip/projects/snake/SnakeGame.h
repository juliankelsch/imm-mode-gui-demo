#ifndef PROCEDURALWORLD_SNAKE_H
#define PROCEDURALWORLD_SNAKE_H

#include "Input.h"

namespace Snake
{
    void UpdateAndRender(input* Input);
    void Shutdown();
}

#endif //PROCEDURALWORLD_SNAKE_H
