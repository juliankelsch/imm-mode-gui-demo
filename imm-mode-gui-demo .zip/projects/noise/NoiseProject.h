#ifndef PROCEDURALWORLD_NOISEPROJECT_H
#define PROCEDURALWORLD_NOISEPROJECT_H

#include "Input.h"

namespace Noise
{
    void UpdateAndRender(input* Input);
    void Shutdown();
}

#endif //PROCEDURALWORLD_NOISEPROJECT_H
